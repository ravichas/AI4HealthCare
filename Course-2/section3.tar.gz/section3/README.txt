Steps: 
 
a) install scikit-learn, tree and dcmtk
   pip install -U scikit-learn
   sudo apt-get install tree # cosmetic
   apt-get install dcmtk
d) start ORTHANC # separate terminal
   bash ./launch_orthanc.sh # leave the terminal running
e) Check whether ORTHANC has started and running using 
    echoscu 127.0.0.1 4242 -v  # leave the terminal running 
f)  Open a new termainal and start OHIF
    bash launch_OHIF.sh
    OHIF viewer will pop up in a browser and will say "No matching found" 
    When you run send_results.sh this will get populated with results.
g) open a new terminal and type the following
g) cd src ; 
    python inference_dcm.py /data/TestVolumes 
h) Note the report.dcm will be produced in the /home/workspace
   This should be sent to out. We could change it in the scripts. 
i) move the report.dcm to /home/workspace/out directory ; and 
i) You will see comments about not able to overwrite files; you can comment the 
   code to avoid this; this is only for jobs running on Udacity workspace; if you 
    are running on your laptop; you will have permission to overwrite them
g) run deploy_scripts/send_result.sh 
   now you will see the results appear in the OHIF viewwer that you started in step f

Take a screen shot and save the image file in out.

For submission create a new section3 directory and copy all the src and out directory into it. 

(medai) root@d710c245090c:/home/workspace/src# deploy_scripts/send_volume.sh 
E: DcmDataDictionary: /opt/aihcnd-applications/dcmtk-3.6.5-linux-x86_64-static/share/dcmtk/dicom.dic: bad VR field (line 2679): OL
E: DcmDataDictionary: /opt/aihcnd-applications/dcmtk-3.6.5-linux-x86_64-static/share/dcmtk/dicom.dic: bad VR field (line 2680): OL
E: DcmDataDictionary: /opt/aihcnd-applications/dcmtk-3.6.5-linux-x86_64-static/share/dcmtk/dicom.dic: bad VR field (line 2681): OL
E: DcmDataDictionary: /opt/aihcnd-applications/dcmtk-3.6.5-linux-x86_64-static/share/dcmtk/dicom.dic: bad VR field (line 2682): OL
E: DcmDataDictionary: /opt/aihcnd-applications/dcmtk-3.6.5-linux-x86_64-static/share/dcmtk/dicom.dic: bad VR field (line 2694): OL
E: DcmDataDictionary: /opt/aihcnd-applications/dcmtk-3.6.5-linux-x86_64-static/share/dcmtk/dicom.dic: bad VR field (line 3004): OL
E: DcmDataDictionary: /opt/aihcnd-applications/dcmtk-3.6.5-linux-x86_64-static/share/dcmtk/dicom.dic: bad VR field (line 4212): OV
E: DcmDataDictionary: /opt/aihcnd-applications/dcmtk-3.6.5-linux-x86_64-static/share/dcmtk/dicom.dic: bad VR field (line 4213): OV
I: determining input files ...
I: checking input files ...
I: Requesting Association
I: Association Accepted (Max Send PDV: 16372)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/9.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 1, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/25.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 2, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/15.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 3, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/17.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 4, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/12.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 5, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/7.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 6, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/4.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 7, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/20.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 8, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/16.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 9, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/24.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 10, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/23.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 11, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/13.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 12, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/1.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 13, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/28.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 14, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/18.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 15, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/3.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 16, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/32.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 17, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/19.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 18, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/14.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 19, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/5.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 20, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/27.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 21, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/8.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 22, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/29.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 23, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/26.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 24, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/31.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 25, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/2.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 26, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/30.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 27, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/6.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 28, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/11.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 29, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/22.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 30, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/21.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 31, MR)
XMIT: .
I: Received Store Response (Success)
I: Sending file: /home/workspace/section3/data/Study1/13_HCropVolume/10.dcm
I: Converting transfer syntax: Little Endian Explicit -> Little Endian Explicit
I: Sending Store Request (MsgID 32, MR)
XMIT: .
I: Received Store Response (Success)
I: Releasing Association
(medai) root@d710c245090c:/home/workspace/src# 

