In actual scripts, the data is located in 
/data/TestVolumes 

% ls -l /data/TestVolumes
total 12
drwxr-xr-x 7 root root 4096 Feb 28  2020 Study1
drwxr-xr-x 7 root root 4096 Feb 28  2020 Study2
drwxr-xr-x 7 root root 4096 Feb 28  2020 Study3

For this demo repo, I have created a local data/TestVolumes directory 
under section3 and copied only Study1/13_HCropVolume/
